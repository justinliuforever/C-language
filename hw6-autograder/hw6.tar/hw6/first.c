#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int mr;
int mw;
int miss;
int hit;
unsigned long int count;

int i,j,min;

typedef struct home{
    unsigned long int tag;
    int status;
    unsigned long int meet;
}home;

struct home** cache;

home** buildCache(int setnum,int assoc){    //2-D malloc cache funtion
  int u,p;
  cache=malloc(setnum*sizeof(home*));      //(home**)
  for(u=0;u<setnum;u++){
    cache[u]=malloc((assoc)*sizeof(home)); //(home*)
  }

  for(u=0;u<setnum;u++){
    for(p=0;p<assoc;p++){
         cache[u][p].status=0;           // block is empty at first
    }
  }
return cache;
}


void coldr(unsigned long int Tagindex,unsigned long int Setindex,int Assoc){
    miss++;
    mr++;
    count++;
    cache[Setindex][i].status=1;
    cache[Setindex][i].tag=Tagindex;
    cache[Setindex][i].meet=count;
}


void coldw(unsigned long int Tagindex,unsigned long int Setindex,int Assoc){
    miss++;
    mr++;
    mw++;
    count++;
    cache[Setindex][i].status=1;
    cache[Setindex][i].tag=Tagindex;
    cache[Setindex][i].meet=count;
}


void readsim(unsigned long int tagI,unsigned long int setI,int assoc){
for(i=0;i<assoc;i++){
    if(cache[setI][i].status==0){//cold
        coldr(tagI, setI, assoc);
    return;
    }else{
        if(cache[setI][i].tag==tagI){     //hit
            hit++;
            return;
        }
        
        if(i==(assoc-1)){                     //replace
            miss++;
            mr++;
            min=0;
            for(j=0;j<assoc;j++){            //finding the oldest hit one
            
            if(cache[setI][j].meet<=cache[setI][min].meet){
                min=j;
                    }
                }
        cache[setI][min].tag=tagI;
        count++;
        cache[setI][min].meet=count;
        cache[setI][min].status=1;
        return;
            }
        }
    }
printf("error");
return;
}


void writesim(unsigned long int tagI,unsigned long int setI,int assoc){
for(i=0;i<assoc;i++){
    if(cache[setI][i].status==0){//miss
        coldw(tagI, setI, assoc);
    return;
    }else{
        if(cache[setI][i].tag==tagI){ //meet
            hit++;
            mw++;
            return;
        }
            
        if(i==(assoc-1)){
            miss++;
            mr++;
            mw++;
            min=0;
            for(j=0;j<assoc;j++){
            
            if(cache[setI][j].meet<=cache[setI][min].meet){
                min=j;
            }
        }
        
        cache[setI][min].tag=tagI;
        count++;
        cache[setI][min].meet=count;
        cache[setI][min].status=1;
        return;
                }
            }
        }
printf("error");
return;
}


void readsiml(unsigned long int tagI,unsigned long int setI,int assoc){
for(i=0;i<assoc;i++){
    if(cache[setI][i].status==0){
        coldr(tagI, setI, assoc);
    return;
    }else{
        if(cache[setI][i].tag==tagI){
            hit++;
            count++;
            cache[setI][i].meet=count;
            return;
        }
            
        if(i==(assoc-1)){
            miss++;
            mr++;
            
            min=0;
            for(j=0;j<assoc;j++){
            
            if(cache[setI][j].meet<=cache[setI][min].meet){
                min=j;
            }
        }
        cache[setI][min].status=1;
        cache[setI][min].tag=tagI;
        count++;
        cache[setI][min].meet=count;
        return;
            }
        }
    }
printf("error");
return;
}

void writesiml(unsigned long int tagI,unsigned long int setI,int assoc){
for(i=0;i<assoc;i++){
    if(cache[setI][i].status==0){
        coldw(tagI, setI, assoc);
    return;
    }else{
        if(cache[setI][i].tag==tagI){
            hit++;
            mw++;
            count++;
            cache[setI][i].meet=count;
            return;
        }
            
        if(i==(assoc-1)){
            miss++;
            mr++;
            mw++;
            min=0;
            for(j=0;j<assoc;j++){
            
            if(cache[setI][j].meet<=cache[setI][min].meet){
                min=j;
            }
        }
        cache[setI][min].status=1;
        cache[setI][min].tag=tagI;
        count++;
        cache[setI][min].meet=count;
        return;
            }
        }
    }
printf("error");
return;
}


int main(int argc, char** argv){
  int cachesize=atoi(argv[1]);
  int blocksize=atoi(argv[4]);
  int n, setnum, assoc;
  int b, s;
  
  char work;
  unsigned long int address, setmask, tagI, setI;
  
  FILE* fl;
  fl=fopen(argv[5],"r");

  if(fl==NULL){
      printf("error");
        exit(2);
  }
    
  if(argv[2][0]=='d'){                        //direct map
      assoc=1;
      setnum=cachesize/blocksize;
  }else if(argv[2][5]!=':'){                  //fullassoc
      setnum=1;
      assoc=cachesize/blocksize;
  }else{                                      //n way associat chache
      sscanf(argv[2],"assoc:%d",&n);
      assoc=n;
      setnum=cachesize/blocksize/n;
    }

    //find out bit in each index and mask
  b=log(blocksize)/log(2);
  s=log(setnum)/log(2);

  setmask=((1<<s)-1);
 
  cache=buildCache(setnum,assoc);
    
    
   //***************************test fifo or Iro************************

if(argv[3][0]=='f'){                          // There is f

  while(fscanf(fl, "%*x: %c %lx", &work, &address)==2){
        //find the index
  setI=(address>>b)&setmask;
  tagI=address>>(b+s);

if(work=='R'){
    readsim(tagI,setI,assoc);
}else if(work=='W'){
    writesim(tagI,setI,assoc);
    }
}
 fclose(fl);
 printf("Memory reads: %d\nMemory writes: %d\nCache hits: %d\nCache misses: %d\n",mr,mw,hit,miss);
        
        
}else if(argv[3][0]=='l'){                      // There is Iru
  while(fscanf(fl, "%*x: %c %lx", &work, &address)==2){

  setI=(address>>b)&setmask;
  tagI=address>>(b+s);

  if(work=='R'){
    
    readsiml(tagI,setI,assoc);
    
    
  }else if(work=='W'){
        writesiml(tagI,setI,assoc);
    }
  }
   fclose(fl);
   printf("Memory reads: %d\nMemory writes: %d\nCache hits: %d\nCache misses: %d\n",mr,mw,hit,miss);
    
    }else{
        printf("error");                    //policy not correct
        }
return 0;
}

